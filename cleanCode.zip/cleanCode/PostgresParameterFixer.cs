namespace t4;

public class PostgresParameterFixer : IparamaterFixer
{
    private string ColumnSeparator => ", ";

    public string GetLogicalOperatorString(LogicalOperator logicalOp)
    {
        return logicalOp.ToString();
    }

    string IparamaterFixer.FormatParameter(int index)
    {
        return $"${index + 1}";
    }

    string IparamaterFixer.ColumnSeparator => ColumnSeparator;

    string IparamaterFixer.WrapIdentifier(string identifier)
    {
        return $"\"{identifier}\"";
    }
}
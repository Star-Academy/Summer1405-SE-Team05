namespace t4;

public class SqlServerCompiler : ICompiler
{
    ISqlCompiler compiler;

    public SqlServerCompiler(ISqlCompiler compiler)
    {
        this.compiler = compiler;
    }

    public SqlResult Compile(Query query)
    {
        return compiler.Compile(query);
    }
}
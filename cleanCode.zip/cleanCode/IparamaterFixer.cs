namespace t4;

public interface IparamaterFixer
{
    string ColumnSeparator { get; }
    string WrapIdentifier(string identifier);

    string FormatParameter(int index);

    object TransformValue(object value)
    {
        return value;
    }

    string GetLogicalOperatorString(LogicalOperator logicalOp);
}
namespace t4;

public class postgresCompiler : ICompiler
{
    ISqlCompiler compiler;
    public SqlResult Compile(Query query)
    {
        return compiler.Compile(query);
    }
}
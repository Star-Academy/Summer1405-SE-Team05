namespace t4;

public class zahediCompiler : ICompiler
{
    public SqlResult Compile(Query query)
    {
        throw new Exception();
    }

}
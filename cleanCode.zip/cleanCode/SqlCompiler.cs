using System.Text;

namespace t4;

public class SqlCompiler : ISqlCompiler
{
    private IparamaterFixer _parameterFixer;

    public SqlCompiler(IparamaterFixer parameterFixer)
    {
        _parameterFixer = parameterFixer;
    }

    public SqlResult Compile(Query query)
    {
        var bindings = new List<object>();
        var sb = new StringBuilder();

        sb.Append(CompileSelect(query));
        sb.Append(" ");
        sb.Append(CompileFrom(query));

        if (query.Clauses.Count > 0)
        {
            sb.Append(" ");
            sb.Append(CompileWhere(query, bindings));
        }

        return new SqlResult(sb.ToString(), bindings);
    }
    

    private string CompileSelect(Query query)
    {
        var cols = query.Columns.Count > 0
            ? string.Join(_paramaterFixer.ColumnSeparator, query.Columns.Select(_paramaterFixer.WrapIdentifier))
            : "*";

        return $"SELECT {cols}";
    }

    private string CompileFrom(Query query)
    {
        return $"FROM {_paramaterFixer.WrapIdentifier(query.Table!)}";
    }

    private string CompileWhere(Query query, List<object> bindings)
    {
        var sb = new StringBuilder("WHERE ");

        for (var i = 0; i < query.Clauses.Count; i++)
        {
            var clause = query.Clauses[i];
            var cond = clause.Condition;

            if (i > 0) sb.Append($" {_paramaterFixer.GetLogicalOperatorString(clause.LogicalOp)} ");

            var paramPlaceholder = _paramaterFixer.FormatParameter(i);
            var processedValue = _paramaterFixer.TransformValue(cond.Value);

            sb.Append($"{_paramaterFixer.WrapIdentifier(cond.Column)} {cond.Operator.Symbol} {paramPlaceholder}");
            bindings.Add(processedValue);
        }

        return sb.ToString();
    }
}
namespace t4;

public class SqlServerParameterFixer : IparamaterFixer
{
    string IparamaterFixer.ColumnSeparator => ", ";

    string IparamaterFixer.FormatParameter(int index)
    {
        return $"@p{index}";
    }

    string IparamaterFixer.WrapIdentifier(string identifier)
    {
        return $"[{identifier}]";
    }

    public string GetLogicalOperatorString(LogicalOperator logicalOp)
    {
        return logicalOp.ToString();
    }
}
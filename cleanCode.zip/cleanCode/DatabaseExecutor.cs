using System.Data.Common;
using Npgsql;

namespace t4;

public class DatabaseExecutor
{
    private readonly ICompiler _compiler;
    private readonly DbConnection _connection;

    public DatabaseExecutor(DbConnection connection, ICompiler compiler)
    {
        _connection = connection;
        _compiler = compiler;
    }

    public void ExecuteAndPrint<T>(Query query, Func<DbDataReader, T> mapper)
    {
        _connection.Open();

        var result = _compiler.Compile(query);
        PrintResult(result);

        using var command = _connection.CreateCommand();
        command.CommandText = result.Sql;

        for (var i = 0; i < result.Bindings.Count; i++)
        {
            var parameter = command.CreateParameter();
            var value = result.Bindings[i] ?? DBNull.Value;


            if (_connection is NpgsqlConnection)
            {
                parameter.Value = value;
            }
            else
            {
                parameter.ParameterName = _compiler.FormatParameter(i);
                parameter.Value = value;
            }

            command.Parameters.Add(parameter);
        }

        using var reader = command.ExecuteReader();
        Console.WriteLine("--- Database Results ---");
        while (reader.Read())
        {
            var record = mapper(reader);
            Console.WriteLine(record);
        }

        Console.WriteLine(new string('=', 40));
    }

    private void PrintResult(SqlResult result)
    {
        Console.WriteLine($"Generated SQL: {result.Sql}");
        Console.WriteLine("Bindings: " + string.Join(", ", result.Bindings));
        Console.WriteLine(new string('-', 40));
    }
}
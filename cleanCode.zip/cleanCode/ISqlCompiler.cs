namespace t4;

public interface ISqlCompiler
{
    SqlResult Compile(Query query);
}